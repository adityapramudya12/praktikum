#include "perhitungan.h"
using namespace std;

const double phi = 3.14;

double luas_kubus(double s) {
    return 6 * s * s;
}

double volume_kubus(double s) {
    return s * s * s;
}

double luas_balok(double p, double l, double t) {
    return 2 * (p * l + p * t + l * t);
}

double volume_balok(double p, double l, double t) {
    return p * l * t;
}

double luas_tabung(double j, double t) {
    double la = phi * j * j;
    double ls = 2 * phi * j * t;
    return 2 * la + ls;
}

double volume_tabung(double j, double t) {
    return phi * j * j * t;
}
