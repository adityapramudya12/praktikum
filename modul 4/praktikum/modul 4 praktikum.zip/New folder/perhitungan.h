#ifndef PERHITUNGAN_H
#define PERHITUNGAN_H

#define output cout
#define masukkan cin
#define ganti endl
#define awal {
#define akhir }
#define mulai main ()
#define tahan return 0


double luas_kubus(double s);
double volume_kubus(double s);
double luas_balok(double p, double l, double t);
double volume_balok(double p, double l, double t);
double luas_tabung(double j, double t);
double volume_tabung(double j, double t);

#endif

