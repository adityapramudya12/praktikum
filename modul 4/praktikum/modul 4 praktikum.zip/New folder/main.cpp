#include <iostream>
#include "perhitungan.h"

using namespace std;

int mulai awal

        double s, p, l, t, j;

        output << "===Program Perhitungan Luas Dan Volume====\n"
                  "===========Kubus, Balok ,Tabung===========" << ganti;

        output << "Masukkan sisi       = ";
        masukkan >> s;

        output << "Masukkan panjang   = ";
        masukkan >> p;

        output << "Masukkan lebar     = ";
        masukkan >> l;

        output << "Masukkan tinggi    = ";
        masukkan >> t;

        output << "Masukkan jari-jari = ";
        masukkan >> j;


        output << "=================================================" << endl;
        output << "Luas Kubus    = " << luas_kubus(s) << endl;
        output << "Luas Balok    = " << luas_balok(p, l, t) << endl;
        output << "Luas Tabung   = " << luas_tabung(j, t) << endl;

        output << "==================================================" << endl;
        output << "Volume Kubus  = " << volume_kubus(s) << endl;
        output << "Volume Balok  = " << volume_balok(p, l, t) << endl;
        output << "Volume Tabung = " << volume_tabung(j, t) << endl;

        tahan;
akhir;